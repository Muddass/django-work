from django.apps import AppConfig


class DsConfig(AppConfig):
    name = 'DS'
