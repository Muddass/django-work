from django.http import HttpResponse
from django.shortcuts import render

def home (request):

    return render(request,"home.html")

def result (request):
    num1=request.GET.get("num1")
    num2=request.GET.get("num2")
    Sum= int(num1) + int(num2)
    dic={"sum":Sum}
    return render(request,"result.html",dic)   