from django.http import HttpResponse
from django.shortcuts import render

def home (request):
    num1=request.GET.get("num1")
    num2=request.GET.get("num2")
    oprator=request.GET.get("oprator")
    answer=None
    if oprator=="+":
        answer= int(num1) + int(num2)
    elif oprator=="-":
        answer= int(num1) - int(num2)
    elif oprator=="*":
        answer= int(num1) * int(num2)
    elif oprator=="/":
        answer= int(num1) / int(num2)
    else:
        print("something went wrong")
    
    dic={"answer":answer}
    
    
    
    
    return render(request,"home.html",dic)

 